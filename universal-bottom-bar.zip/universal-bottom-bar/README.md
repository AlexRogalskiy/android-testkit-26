# Universal-bottom-bar
Drawer plus bottombar

Have you tired of using drawer plus bottom bar?
Use this code which contains both together.
It is just initiate to do something new.


[![Whatch the video](https://img.youtube.com/vi/=1Q2K8cLUuC8/0.jpg)](https://www.youtube.com/watch?v=1Q2K8cLUuC8)

